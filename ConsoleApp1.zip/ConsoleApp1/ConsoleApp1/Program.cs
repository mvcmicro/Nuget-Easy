﻿using System;
using ExcelDataReader;
using System.IO;
using System.Data;
using System.Text;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Text.Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            string t = @"D:\@EXcel\WWWEE.xlsx";
            FileStream stream = File.Open(t, FileMode.Open, FileAccess.Read);
            IExcelDataReader excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
            DataSet result = excelReader.AsDataSet();
        }
    }
}
