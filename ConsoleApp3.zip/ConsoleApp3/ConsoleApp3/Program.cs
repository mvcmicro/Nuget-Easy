﻿
using ExcelDataReader;
using System.IO;
using System.Data;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            string t = @"D:\@EXcel\xls.xls";
            FileStream stream = File.Open(t, FileMode.Open, FileAccess.Read);
            IExcelDataReader excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
            // IExcelDataReader excelReader = ExcelReaderFactory.CreateReader(stream);
            DataSet result = excelReader.AsDataSet();
        }
    }
}
